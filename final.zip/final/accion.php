<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
 print_r($_REQUEST);
 if($_REQUEST["respuesta"] == "1"){

    print("<h1>Mostrar proveïdors</h1>");

print("<form action=\"index.php\" method=\"post\">");

    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS mercadona";
    if ($conn->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error creating database: " . $conn->error;
    }
    
    $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS proveidors(
        cif VARCHAR(255) PRIMARY KEY,
        nom VARCHAR(255),
        cognom1 VARCHAR(255),
        cognom2 VARCHAR(255),
        adreca VARCHAR(255),
        telf VARCHAR(255)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS productes(
        product VARCHAR(255) PRIMARY KEY,
        marca VARCHAR(255),
        producte VARCHAR(255),
        descripcio VARCHAR(255),
        preu VARCHAR(255),
        proveidor VARCHAR(255),
        FOREIGN KEY (proveidor) REFERENCES proveidors(cif)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();
    
        $servername = "localhost";
        $username = "juan";
        $password = "juan";
        $dbname = "mercadona";
        
        // Create connection withc dbname
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        echo "";

//sql to select data
$sql = "SELECT cif,nom,cognom1,cognom2,adreca,telf  FROM proveidors";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "Cif: " . $row["cif"]. " Nom: " . $row["nom"]. " Cognom1:" . $row["cognom1"]. " Cognim2: " . $row["cognom2"]. " Adreça: " . $row["adreca"]. " Telefon: " . $row["telf"] ."<br>";
  }
} else {
  echo "0 results";
}
print("<br></br>");
print("<input type='submit' value='Darere'>");
print("</form>");
$conn->close();

    
 }
 elseif($_REQUEST["respuesta"] == "2"){
    print("<h1>Insertar proveïdor</h1>");
    print("<form action='2.php' method='post'>");
    print("<p>Cif: <input type='text' name='cif'></p>");
    print("<p>Nom: <input type='text' name='nom'></p>");
    print("<p>Cognom 1: <input type='text' name='cog1'> Cognom 2: <input type='text' name='cog2'></p>");
    print("<p>Adreça: <input type='text' name='adreca'></p>");
    print("<p>Telf: <input type='text' name='telf'></p>");
    print("<input type='submit' value='Enviar'>");
    print("</form>");
 }
 elseif($_REQUEST["respuesta"] == "3"){

    print("<h1>Eliminar proveïdor</h1>");

    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS mercadona";
    if ($conn->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error creating database: " . $conn->error;
    }
    
    $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS proveidors(
        cif VARCHAR(255) PRIMARY KEY,
        nom VARCHAR(255),
        cognom1 VARCHAR(255),
        cognom2 VARCHAR(255),
        adreca VARCHAR(255),
        telf VARCHAR(255)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS productes(
        product VARCHAR(255) PRIMARY KEY,
        marca VARCHAR(255),
        producte VARCHAR(255),
        descripcio VARCHAR(255),
        preu VARCHAR(255),
        proveidor VARCHAR(255),
        FOREIGN KEY (proveidor) REFERENCES proveidors(cif)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();

        $servername = "localhost";
        $username = "juan";
        $password = "juan";
        $dbname = "mercadona";
        
        // Create connection withc dbname
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        echo "";

        //sql to select data
$sql = "SELECT cif,nom,cognom1,cognom2,adreca,telf  FROM proveidors";
$result = $conn->query($sql);

print("<form action='3.php' method='post'>");
print "<select name='re1'>";
  print "<option value='DELPRO' selected='selected'>";
  print "seleccionar proveïdor";
  print "</option>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          $id=$row["cif"];
          $nom_alumno=$row["nom"] . " " . $row["cognom1"] . " " . $row["cognom2"] ;
          print "<option value=\"$id\">";
          print  $nom_alumno;
          print "</option>";
                
      }// end while while
   print "</select>";
  } //end if
 else {
  echo "0 results";
}
print("<input type='submit' value='Esborrar'>");
print("</form>");
$conn->close();
 

 }
 elseif($_REQUEST["respuesta"] == "4"){


    

 }
 elseif($_REQUEST["respuesta"] == "5"){

    print("<h1>Mostrar productes</h1>");

    print("<form action='index.php' method='post'>");

    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS mercadona";
    if ($conn->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error creating database: " . $conn->error;
    }
    
    $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS proveidors(
        cif VARCHAR(255) PRIMARY KEY,
        nom VARCHAR(255),
        cognom1 VARCHAR(255),
        cognom2 VARCHAR(255),
        adreca VARCHAR(255),
        telf VARCHAR(255)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS productes(
        product VARCHAR(255) PRIMARY KEY,
        marca VARCHAR(255),
        producte VARCHAR(255),
        descripcio VARCHAR(255),
        preu VARCHAR(255),
        proveidor VARCHAR(255),
        FOREIGN KEY (proveidor) REFERENCES proveidors(cif)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();
    
        $servername = "localhost";
        $username = "juan";
        $password = "juan";
        $dbname = "mercadona";
        
        // Create connection withc dbname
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        echo "";

//sql to select data
$sql = "SELECT product,marca,producte,descripcio,preu,proveidor  FROM productes";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "Product: " . $row["product"]. " Marca: " . $row["marca"]. " Producte:" . $row["producte"]. " Descripcio: " . $row["descripcio"]. " Preu: " . $row["preu"]. " Proveidor: " . $row["proveidor"] ."<br>";
  }
} else {
  echo "0 results";
}
print("<br></br>");
print("<input type='submit' value='Darere'>");
print("</form>");
$conn->close();





 }
 elseif($_REQUEST["respuesta"] == "6"){
    print("<h1>Insertar producte</h1>");
    print("<form action='6.php' method='post'>");
    print("<p>Product: <input type='text' name='product'></p>");
    print("<p>Marca: <input type='text' name='marca'></p>");
    print("<p>Producte: <input type='text' name='producte'>");
    print("<p>Descripció: <input type='text' name='descripcio'></p>");
    print("<p>Preu: <input type='text' name='preu'></p>");
    print("<p>Proveïdor: <input type='text' name='proveidor'></p>");
    print("<input type='submit'>");
    print("</form>");
 }
 elseif($_REQUEST["respuesta"] == "7"){

    print("<h1>Eliminar proveïdor</h1>");

    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    // Create database
    $sql = "CREATE DATABASE IF NOT EXISTS mercadona";
    if ($conn->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error creating database: " . $conn->error;
    }
    
    $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS proveidors(
        cif VARCHAR(255) PRIMARY KEY,
        nom VARCHAR(255),
        cognom1 VARCHAR(255),
        cognom2 VARCHAR(255),
        adreca VARCHAR(255),
        telf VARCHAR(255)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();
    
    $servername = "localhost";
    $username = "juan";
    $password = "juan";
    $dbname = "mercadona";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "";
    
    
    // sql to create table
    $sql = "CREATE TABLE IF NOT EXISTS productes(
        product VARCHAR(255) PRIMARY KEY,
        marca VARCHAR(255),
        producte VARCHAR(255),
        descripcio VARCHAR(255),
        preu VARCHAR(255),
        proveidor VARCHAR(255),
        FOREIGN KEY (proveidor) REFERENCES proveidors(cif)
        )";
        
        if ($conn->query($sql) === TRUE) {
          echo "";
        } else {
          echo "Error creant taula " . $conn->error;
        }
        
        $conn->close();

        $servername = "localhost";
        $username = "juan";
        $password = "juan";
        $dbname = "mercadona";
        
        // Create connection withc dbname
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        echo "";

        //sql to select data
$sql = "SELECT product,marca,producte,descripcio,preu,proveidor  FROM productes";
$result = $conn->query($sql);

print("<form action='7.php' method='post'>");
print "<select name='re2'>";
  print "<option value='DELPRO2' selected='selected'>";
  print "seleccionar proveïdor";
  print "</option>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
          $id=$row["product"];
          $nom_alumno=$row["marca"] . " " . $row["producte"] ;
          print "<option value=\"$id\">";
          print  $nom_alumno;
          print "</option>";
                
      }// end while while
   print "</select>";
  } //end if
 else {
  echo "0 results";
}
print("<input type='submit'>");
print("</form>");
$conn->close();



 }
 elseif($_REQUEST["respuesta"] == "8"){

 }
else{
    echo "Error 404";
}
?>


</body>
</html>