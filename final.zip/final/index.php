<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <!--

    <h1>Mercadona Opcions</h1>
    <form action="accion.php" method="post">
    <label for="opcion">Choose your browser from the list:</label>
    <input list="opcion" name="opcion" id="opcion">
        <datalist id="opcion">
        <option value="Mostrar proveïdors">
        <option value="Insertar proveïdor">
        <option value="Eliminar proveïdor">
        <option value="Modificar proveïdor">
        <option value="Mostrar Productes">
        <option value="Insertar Producte">
        <option value="Eliminar producte">
        <option value="Modificar productes">
        </datalist>   
<input type="submit" value="Enviar">
</form>
--> 
<h1>Mercadona Opcions</h1>

<?php

$servername = "localhost";
$username = "juan";
$password = "juan";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "";

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS mercadona";
if ($conn->query($sql) === TRUE) {
  echo "";
} else {
  echo "Error creating database: " . $conn->error;
}

$conn->close();

$servername = "localhost";
$username = "juan";
$password = "juan";
$dbname = "mercadona";

// Create connection withc dbname
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "";


// sql to create table
$sql = "CREATE TABLE IF NOT EXISTS proveidors(
    cif VARCHAR(255) PRIMARY KEY,
    nom VARCHAR(255),
    cognom1 VARCHAR(255),
    cognom2 VARCHAR(255),
    adreca VARCHAR(255),
    telf VARCHAR(255)
    )";
    
    if ($conn->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error creant taula " . $conn->error;
    }
    
    $conn->close();

    $servername = "localhost";
$username = "juan";
$password = "juan";
$dbname = "mercadona";

// Create connection withc dbname
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "";


// sql to create table
$sql = "CREATE TABLE IF NOT EXISTS productes(
    product VARCHAR(255) PRIMARY KEY,
    marca VARCHAR(255),
    producte VARCHAR(255),
    descripcio VARCHAR(255),
    preu VARCHAR(255),
    proveidor VARCHAR(255),
    FOREIGN KEY (proveidor) REFERENCES proveidors(cif)
    )";
    
    if ($conn->query($sql) === TRUE) {
      echo "";
    } else {
      echo "Error creant taula " . $conn->error;
    }
    
    $conn->close();



?>

<form action="accion.php" method="post">
  <select name="respuesta">
      <option value="1">Mostrar proveïdors</option>
      <option value="2">Insertar proveïdor</option>
      <option value="3">Eliminar proveïdor</option>
      <option value="4">Modificar proveïdor</option>
      <option value="5">Mostrar Productes</option>
      <option value="6">Insertar Producte</option>
      <option value="7">Eliminar producte</option>
      <option value="8">Modificar productes</option>
  </select>
  <input type="submit" value="Enviar">
  </form>

</body>
</html>