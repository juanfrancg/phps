<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Daus</h1>
    <?php
    $totalj1=0;
    $totalj2=0;
    $res1=$_REQUEST["jugadora"];
    $res2=$_REQUEST["jugadorb"];

    if(($_REQUEST["jugadora"] == 0) && ($_REQUEST["jugadorb"] == 0)){
        print("El jugador 1 no ha seleccionado el numero de dados<br>");
        print("El jugador 2 no ha seleccionado el numero de dados");
    }
    else{
        print("<h1>Jugador 1</h1>");
        for($i=0;$i<$res1;$i++){
            $cartaj1=rand(1,6);
            print("<img src='cartas/$cartaj1.svg' alt='cartas' weight='200px' height='200px'>");
            $totalj1 += $cartaj1;
        }
        print("$totalj1");
        print("<h1>Jugador 2</h1>");
        for($i=0;$i<$res2;$i++){
            $cartaj2=rand(1,6);
            print("<img src='cartas/$cartaj2.svg' alt='cartas' weight='200px' height='200px'>");
            $totalj2 += $cartaj2;
        }
    }
    
print("$totalj2");

if($totalj1 > $totalj2){
    print("Gana el Jugador 1");
}
elseif($totalj2 > $totalj1){
    print("Gana el Jugador 2");
}
else{
    if($res1 < $res2){
        print("Gana el jugador 1");
    }
    elseif($res2 < $res1){
        print("Gana el jugador 2");
    }
    else{
        print("Empate");
    }
}


    ?>



</body>
</html>