<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<form action="accion.php" method="post">

<h1>Daus</h1>
<p>Indica quantas daus vols que tire cada jugador:</p>
<p>Jugador A: <select name="jugadora">
<option value="0">selecciona daus</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>


</select></p>

<p>Jugador B:
<select name="jugadorb">
<option value="0">selecciona daus</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
</select></p>

<p><input type="submit" value="Enviar"><input type="reset" value="Borrar"></p>
</form>
</body>
</html>