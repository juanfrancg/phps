<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP & MySQL</title>
</head>
<body>

<?php
$servername = "localhost";
$username = "david";
$password = "1234";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


// Create database
$sql = "CREATE DATABASE IF NOT EXISTS barbilla";
if ($conn->query($sql) === TRUE) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . $conn->error;
}

$conn->close();



$servername = "localhost";
$username = "david";
$password = "1234";
$dbname = "barbilla";

// Create connection withc dbname
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


// sql to create table
$sql = "CREATE TABLE IF NOT EXISTS alumno (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(30) NOT NULL,
    cognoms VARCHAR(30) NOT NULL,
    email VARCHAR(50),
    modul VARCHAR(50),
    nota VARCHAR(50),
    edat VARCHAR(50)
    )";
    
    if ($conn->query($sql) === TRUE) {
      echo "Taula alumnos creada correctament";
    } else {
      echo "Error creant taula " . $conn->error;
    }
    
    $conn->close();
/*
    $servername = "localhost";
    $username = "david";
    $password = "1234";
    $dbname = "barbilla";
    
    // Create connection withc dbname
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully";
    
    
    //sql to insert data
    //fixat al ; final per tal d'afegir noves instruccions a continuació
    $sql = "INSERT INTO alumno (nom, cognoms,email,modul,nota,edat)
    VALUES ('Juanfran', 'Joan Pérez','juanfran@gmail.com','iaw','3','18');";
    
    //utilitze operador .= .Concatena i assigna
    $sql .= "INSERT INTO alumno (nom, cognoms,email,modul,nota,edat)
    VALUES ('Jose', 'Lujan Torres','jose@gmail.com','iaw','3','20');";
    
    $sql .= "INSERT INTO alumno (nom, cognoms,email,modul,nota,edat)
    VALUES ('Emi', 'Juan Gómez','emi@example.com','iaw','3','19')";
    
    
    //utilitze funció multi_query
    if ($conn->multi_query($sql) === TRUE) {
      echo "Nou registres creats correctament";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
*/


$servername = "localhost";
$username = "david";
$password = "1234";
$dbname = "barbilla";

// Create connection with dbname
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: <br>" . $conn->connect_error);
}
echo "Connected successfully <br>";

//sql to select data
$sql = "SELECT id,nom,cognoms,email,modul,nota,edat FROM alumno";
$result = $conn->query($sql);

echo "<table>";
echo "<tr><th>ID</th><th>NOM</th><th>COGNOMS</th><th>EMAIL</th><th>MODULO</th><th>NOTA</th><th>EDAT</th></tr>";

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>" . $row["id"]. "</td><td>" . $row["nom"]. "</td><td>" . $row["cognoms"]. "</td><td>" . $row["email"]."</td><td>". $row["modul"]."</td><td>". $row["nota"]."</td><td>". $row["edat"]."</td></tr>";
  }
} else {
  echo "<tr><td colspan='7'>0 results</td></tr>";
}
echo "</table>";

$conn->close();





?>
  





</body>
</html>