<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>

<h1>Parells guanyen</h1>
    
<?php

$par=0;



for($i=0;$i<6;$i++){
    $cartas=rand(1,10);
    print("<img src='cartas/$cartas.svg' alt='cartas' weight='200px' height='200px'>");
    if( $cartas % 2 == 0){
        $par += 1;
    }
}

print($par);



if( $par >= 3){
    print("Ganador");
}
else{
    print("Perdedor");
}


?>




</body>
</html>